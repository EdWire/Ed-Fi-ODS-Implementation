do $$ 
<<resourceclaims_block>>
declare
  	vApplicationId integer := 0;
	vSystemDescriptorsId integer := 0;
begin
	raise notice 'Descriptor block started';
	  
	SELECT ApplicationId
	INTO vApplicationId
	FROM dbo.Applications
	WHERE ApplicationName = 'Ed-Fi ODS API';

	SELECT resourceclaimid
	INTO vSystemDescriptorsId
	FROM   dbo.resourceclaims
	WHERE  displayname = 'systemDescriptors';

	INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'adaeligibilitydescriptor',
	              	'adaeligibilitydescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/adaeligibilitydescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'armedservicesvocaptbatteryindicatordescriptor',
	              	'armedservicesvocaptbatteryindicatordescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/armedservicesvocaptbatteryindicatordescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'assessmentresultsobtaineddescriptor',
	              	'assessmentresultsobtaineddescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/assessmentresultsobtaineddescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'auxiliaryroleiddescriptor',
	              	'auxiliaryroleiddescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/auxiliaryroleiddescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'calendarwaivereventtypedescriptor',
	              	'calendarwaivereventtypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/calendarwaivereventtypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'campusenrollmenttypedescriptor',
	              	'campusenrollmenttypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/campusenrollmenttypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'childcountfundingdescriptor',
	              	'childcountfundingdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/childcountfundingdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'classtypedescriptor',
	              	'classtypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/classtypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'coursesequencedescriptor',
	              	'coursesequencedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/coursesequencedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'crisiseventdescriptor',
	              	'crisiseventdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/crisiseventdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'dyslexiariskdescriptor',
	              	'dyslexiariskdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/dyslexiariskdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'dyslexiaservicesdescriptor',
	              	'dyslexiaservicesdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/dyslexiaservicesdescriptor',
					vSystemDescriptorsId,
					vApplicationId );					
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'earlyreadingindicatordescriptor',
	              	'earlyreadingindicatordescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/earlyreadingindicatordescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'economicdisadvantagedescriptor',
	              	'economicdisadvantagedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/economicdisadvantagedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'eloactivitydescriptor',
	              	'eloactivitydescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/eloactivitydescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'elotypedescriptor',
	              	'elotypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/elotypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'endorsementcompleteddescriptor',
	              	'endorsementcompleteddescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/endorsementcompleteddescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'endorsementpursuingdescriptor',
	              	'endorsementpursuingdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/endorsementpursuingdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'evaluationdelayreasondescriptor',
	              	'evaluationdelayreasondescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/evaluationdelayreasondescriptor',
					vSystemDescriptorsId,
					vApplicationId );				
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'fostercaretypedescriptor',
	              	'fostercaretypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/fostercaretypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'frequencyofservicesdescriptor',
	              	'frequencyofservicesdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/frequencyofservicesdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'generationcodedescriptor',
	              	'generationcodedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/generationcodedescriptor',
					vSystemDescriptorsId,
					vApplicationId );					
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'giftedtalentedprogramdescriptor',
	              	'giftedtalentedprogramdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/giftedtalentedprogramdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'gradeLevelDescriptor',
	              	'gradeLevelDescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/gradeLevelDescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'hearingamplifavgdailyusedescriptor',
	              	'hearingamplifavgdailyusedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/hearingamplifavgdailyusedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'hearingamplificationaccessdescriptor',
	              	'hearingamplificationaccessdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/hearingamplificationaccessdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'hearingamplificationtypedescriptor',
	              	'hearingamplificationtypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/hearingamplificationtypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'homelessstatusdescriptor',
	              	'homelessstatusdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/homelessstatusdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'hoursspentreceivingservicesdescriptor',
	              	'hoursspentreceivingservicesdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/hoursspentreceivingservicesdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'ibcvendordescriptor',
	              	'ibcvendordescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/ibcvendordescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'langacqservicesprovideddescriptor',
	              	'langacqservicesprovideddescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/langacqservicesprovideddescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'militaryconnectedstudentdescriptor',
	              	'militaryconnectedstudentdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/militaryconnectedstudentdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'noncampusbasedinstructiondescriptor',
	              	'noncampusbasedinstructiondescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/noncampusbasedinstructiondescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'nslptypedescriptor',
	              	'nslptypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/nslptypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'parentalpermissiondescriptor',
	              	'parentalpermissiondescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/parentalpermissiondescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'pkcurriculadescriptor',
	              	'pkcurriculadescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/pkcurriculadescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'pkfundingsourcedescriptor',
	              	'pkfundingsourcedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/pkfundingsourcedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'pkprogramevaluationtypedescriptor',
	              	'pkprogramevaluationtypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/pkprogramevaluationtypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'pkprogramtypedescriptor',
	              	'pkprogramtypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/pkprogramtypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'pkschooltypedescriptor',
	              	'pkschooltypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/pkschooltypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'pkstudentinstructiondescriptor',
	              	'pkstudentinstructiondescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/pkstudentinstructiondescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'pkteacherrequirementdescriptor',
	              	'pkteacherrequirementdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/pkteacherrequirementdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'postsecondarycertificationlicensuredescriptor',
	              	'postsecondarycertificationlicensuredescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/postsecondarycertificationlicensuredescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'ppcdservicelocationdescriptor',
	              	'ppcdservicelocationdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/ppcdservicelocationdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'preferredhomecommunicationmethoddescriptor',
	              	'preferredhomecommunicationmethoddescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/preferredhomecommunicationmethoddescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'programofstudydescriptor',
	              	'programofstudydescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/programofstudydescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'restraintstafftypedescriptor',
	              	'restraintstafftypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/restraintstafftypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'roleiddescriptor',
	              	'roleiddescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/roleiddescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'serviceiddescriptor',
	              	'serviceiddescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/serviceiddescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'sharedservicearrangementstaffdescriptor',
	              	'sharedservicearrangementstaffdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/sharedservicearrangementstaffdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'stafftypedescriptor',
	              	'stafftypedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/stafftypedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'studentattributiondescriptor',
	              	'studentattributiondescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/studentattributiondescriptor',
					vSystemDescriptorsId,
					vApplicationId );				
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'teacherincentiveallotmentdesignationcodedescriptor',
	              	'teacherincentiveallotmentdesignationcodedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/teacherincentiveallotmentdesignationcodedescriptor',
					vSystemDescriptorsId,
					vApplicationId );					
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'toolorassessmentuseddescriptor',
	              	'toolorassessmentuseddescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/toolorassessmentuseddescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'unaccompaniedyouthdescriptor',
	              	'unaccompaniedyouthdescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/unaccompaniedyouthdescriptor',
					vSystemDescriptorsId,
					vApplicationId );
INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'unschooledasyleerefugeedescriptor',
	              	'unschooledasyleerefugeedescriptor',
					'http://ed-fi.org/ods/identity/claims/tx/unschooledasyleerefugeedescriptor',
					vSystemDescriptorsId,
					vApplicationId );
			
   -- display a message
   raise notice 'Descriptor block completed';
  raise notice 'Starting with new entities';
  
  INSERT INTO dbo.resourceclaims
	            (displayname,
	             resourcename,
	             claimname,
	             parentresourceclaimid,
	             application_applicationid)
	VALUES      ( 	'StaffResponsibilities',
	              	'StaffResponsibilities',
					'http://ed-fi.org/ods/identity/claims/tx/StaffResponsibilities',
					null,--vSystemDescriptorsId,
					vApplicationId );
	raise notice 'New entities block completed';			
end resourceclaims_block $$;

-----Authorization for new Domain Entity StaffResponsibilities

do $$
<<Authorization_block>>
declare
    vAuthorizationStrategyId integer := 0;
    vResourceClaimId integer := 0;
begin
    raise notice 'Authorization for StaffResponsibilities started';

    SELECT AuthorizationStrategyId
    into    vAuthorizationStrategyId
    FROM dbo.AuthorizationStrategies
    WHERE AuthorizationStrategyName = 'RelationshipsWithEdOrgsAndPeople'; --***********IS THIS WHAT WE WANT????***********************

    SELECT resourceclaimid
    into vResourceClaimId
    FROM dbo.ResourceClaims
    WHERE ResourceName = 'StaffResponsibilities';

    INSERT INTO dbo.ResourceClaimAuthorizationMetadatas (action_actionid, authorizationstrategy_authorizationstrategyid, resourceclaim_resourceclaimid)
    SELECT ActionId
        ,vAuthorizationStrategyId
        ,vResourceClaimId
    FROM dbo.Actions a
    WHERE NOT EXISTS (
            SELECT 1
            FROM dbo.ResourceClaimAuthorizationMetadatas
            WHERE Action_ActionId = a.ActionId
                AND AuthorizationStrategy_AuthorizationStrategyId = vAuthorizationStrategyId
                AND ResourceClaim_ResourceClaimId = vResourceClaimId
            );

    --Add to SIS Vendor and Ed-Fi Sandbox claim sets
    INSERT INTO dbo.ClaimSetResourceClaims (action_actionid, claimset_claimsetid, resourceclaim_resourceclaimid)
    SELECT ActionId
        ,ClaimSetId
        ,ResourceClaimId
    FROM dbo.Actions a
        , dbo.ClaimSets c
        , dbo.ResourceClaims r
    WHERE r.ResourceName = 'StaffResponsibilities'
        AND (
            c.ClaimSetName = 'SIS Vendor'
            OR c.ClaimSetName = 'Ed-Fi Sandbox'
            )
        AND NOT EXISTS (
            SELECT 1
            FROM dbo.ClaimSetResourceClaims
            WHERE Action_ActionId = a.ActionId
                AND ClaimSet_ClaimSetId = c.ClaimSetId
                AND ResourceClaim_ResourceClaimId = r.ResourceClaimId
            );

    raise notice 'Authorization for StaffResponsibilities ENDED';
end Authorization_block $$;

--delete repeated claims in case this script was run more than once
delete from dbo.claimsetresourceclaims c
where c.resourceclaim_resourceclaimid in (select rc1.resourceclaimid 
	from dbo.resourceclaims rc1 
	join dbo.resourceclaims rc2 on  
	 rc1.displayname = rc2.displayname 
	and rc1.resourcename = rc2.resourcename 
	and rc1.claimname = rc2.claimname 
	and (rc1.parentresourceclaimid = rc2.parentresourceclaimid or rc1.parentresourceclaimid is null and rc2.parentresourceclaimid is null)
	and rc1.application_applicationid = rc2.application_applicationid 
	where  rc1.resourceclaimid > rc2.resourceclaimid)
;
delete from dbo.resourceclaims rc1
using dbo.resourceclaims rc2
where rc1.resourceclaimid > rc2.resourceclaimid 
	and rc1.displayname = rc2.displayname 
	and rc1.resourcename = rc2.resourcename 
	and rc1.claimname = rc2.claimname 
	and (rc1.parentresourceclaimid = rc2.parentresourceclaimid or rc1.parentresourceclaimid is null and rc2.parentresourceclaimid is null)
	and rc1.application_applicationid = rc2.application_applicationid 
;
end